import React, { useState } from 'react';
import { Search, MapPin, Phone, Shield, AlertTriangle, Info, Globe, Clock, DollarSign, MessageSquare, Navigation, Building2 } from 'lucide-react';
import { getPhoneInfo, validatePhoneNumber, phoneDatabase, PhoneInfo } from './data/phoneData';

function App() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneInfo, setPhoneInfo] = useState<PhoneInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showCountryList, setShowCountryList] = useState(false);

  const handleLookup = async () => {
    if (!phoneNumber.trim()) {
      setError('Please enter a phone number');
      return;
    }

    if (!validatePhoneNumber(phoneNumber)) {
      setError('Please enter a valid phone number with country code');
      return;
    }

    setIsLoading(true);
    setError('');

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const info = getPhoneInfo(phoneNumber);
    if (info) {
      setPhoneInfo(info);
    } else {
      setError('Could not retrieve information for this number');
    }

    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleLookup();
    }
  };

  const getNumberTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'mobile': return 'bg-green-50 text-green-800 border-green-200';
      case 'landline': return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'toll-free': return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'premium rate': return 'bg-red-50 text-red-800 border-red-200';
      case 'emergency': return 'bg-orange-50 text-orange-800 border-orange-200';
      case 'short code': return 'bg-yellow-50 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-50 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
                <Phone className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">PhoneTrace Global</h1>
                <p className="text-xs text-gray-500">Advanced Phone Number Intelligence & Location Services</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowCountryList(!showCountryList)}
                className="flex items-center space-x-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                <Globe className="h-4 w-4" />
                <span>Countries ({Object.keys(phoneDatabase).length})</span>
              </button>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Shield className="h-4 w-4" />
                <span>Privacy Protected</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Country List Modal */}
        {showCountryList && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">Supported Countries & Regions</h2>
                  <button
                    onClick={() => setShowCountryList(false)}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="p-6 overflow-y-auto max-h-[60vh]">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(phoneDatabase).map(([code, data]) => (
                    <div key={code} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">{data.country}</span>
                        <span className="text-sm font-mono bg-blue-100 text-blue-800 px-2 py-1 rounded">{code}</span>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-3 w-3" />
                          <span>{data.region}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Clock className="h-3 w-3" />
                          <span>{data.timezone}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="h-3 w-3" />
                          <span>{data.currency}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MessageSquare className="h-3 w-3" />
                          <span>{data.language}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Building2 className="h-3 w-3" />
                          <span>{data.carriers.length} Carriers</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Privacy Notice */}
        <div className="mb-8 bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-amber-800 mb-1">Privacy & Legal Notice</h3>
              <p className="text-amber-700 text-sm">
                This tool provides general information about phone numbers for educational purposes only. 
                Real-time location tracking requires proper authorization and user consent. Always respect privacy laws and regulations.
                Data shown is based on public numbering plans and carrier databases.
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Search Section */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Global Phone Number Lookup</h2>
              <p className="text-gray-600">
                Enter any international phone number to get comprehensive carrier, location, and regional information
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number (with country code)
                </label>
                <div className="relative">
                  <input
                    id="phone"
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="+1 555 123 4567, +44 20 7946 0958, +91 98765 43210"
                    className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                  />
                  <Phone className="absolute right-4 top-3.5 h-5 w-5 text-gray-400" />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Examples: +1 (US/CA), +44 (UK), +91 (IN), +86 (CN), +49 (DE), +33 (FR), +81 (JP)
                </p>
              </div>

              {error && (
                <div className="text-red-600 text-sm bg-red-50 border border-red-200 rounded-lg p-3">
                  {error}
                </div>
              )}

              <button
                onClick={handleLookup}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <Search className="h-5 w-5" />
                    <span>Analyze Number</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            {phoneInfo ? (
              <div>
                <div className="flex items-center space-x-2 mb-6">
                  <Navigation className="h-5 w-5 text-green-600" />
                  <h3 className="text-xl font-semibold text-gray-900">Number Analysis Results</h3>
                </div>
                
                <div className="space-y-4">
                  {/* Number Type Badge */}
                  <div className="flex justify-center mb-4">
                    <span className={`px-4 py-2 rounded-full text-sm font-semibold border ${getNumberTypeColor(phoneInfo.type)}`}>
                      {phoneInfo.type} Number
                    </span>
                  </div>

                  {/* Location Information */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2 flex items-center space-x-2">
                      <MapPin className="h-4 w-4" />
                      <span>Location Information</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-blue-600">City</p>
                        <p className="font-semibold text-blue-900">{phoneInfo.city}</p>
                      </div>
                      <div>
                        <p className="text-xs text-blue-600">State/Province</p>
                        <p className="font-semibold text-blue-900">{phoneInfo.state}</p>
                      </div>
                    </div>
                    {phoneInfo.coordinates && (
                      <div className="mt-2 text-xs text-blue-600">
                        Coordinates: {phoneInfo.coordinates.lat.toFixed(4)}, {phoneInfo.coordinates.lng.toFixed(4)}
                      </div>
                    )}
                  </div>

                  {/* Carrier Information */}
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                    <h4 className="font-semibold text-green-900 mb-2 flex items-center space-x-2">
                      <Building2 className="h-4 w-4" />
                      <span>Carrier Information</span>
                    </h4>
                    <p className="font-semibold text-green-900 text-lg">{phoneInfo.carrier}</p>
                    <p className="text-xs text-green-600 mt-1">*Based on number prefix analysis and carrier databases</p>
                  </div>

                  {/* Basic Info Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Country</p>
                      <p className="font-semibold text-gray-900">{phoneInfo.country}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Country Code</p>
                      <p className="font-semibold text-gray-900 font-mono">{phoneInfo.countryCode}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Region</p>
                      <p className="font-semibold text-gray-900">{phoneInfo.region}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Timezone</p>
                      <p className="font-semibold text-gray-900">{phoneInfo.timezone}</p>
                    </div>
                  </div>

                  {/* Additional Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Currency</p>
                      <p className="font-semibold text-gray-900">{phoneInfo.currency}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Language</p>
                      <p className="font-semibold text-gray-900">{phoneInfo.language}</p>
                    </div>
                  </div>

                  {/* Validation Status */}
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-green-800 font-medium">Valid International Format</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-gray-100 rounded-full p-4 w-16 h-16 mx-auto mb-4">
                  <Search className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Analysis Yet</h3>
                <p className="text-gray-600">
                  Enter a phone number to see comprehensive carrier, location, and regional information
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Number Types Information */}
        <div className="mt-12 bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <div className="flex items-center space-x-2 mb-6">
            <Info className="h-5 w-5 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-900">Phone Number Types Explained</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span>Mobile Numbers</span>
              </h4>
              <p className="text-sm text-gray-600">
                Cellular/mobile phone numbers assigned to wireless devices. Usually portable between carriers and provide precise location data.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span>Landline Numbers</span>
              </h4>
              <p className="text-sm text-gray-600">
                Fixed-line telephone numbers tied to specific geographic locations and physical connections. Provide accurate city-level location.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                <span>Toll-Free Numbers</span>
              </h4>
              <p className="text-sm text-gray-600">
                Free-to-call numbers where the receiving party pays for the call. Common for businesses and customer service.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span>Premium Rate</span>
              </h4>
              <p className="text-sm text-gray-600">
                High-cost numbers that charge premium rates, often used for services, contests, or adult content.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                <span>Emergency Numbers</span>
              </h4>
              <p className="text-sm text-gray-600">
                Special numbers for emergency services like police, fire, ambulance (911, 999, 112, etc.).
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span>Short Codes</span>
              </h4>
              <p className="text-sm text-gray-600">
                Brief numeric codes for services, information lines, or SMS services (typically 3-6 digits).
              </p>
            </div>
          </div>
        </div>

        {/* Enhanced Technical Information */}
        <div className="mt-8 bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <div className="flex items-center space-x-2 mb-4">
            <Shield className="h-5 w-5 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-900">Advanced Phone Intelligence Technology</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Carrier Detection Methods</h4>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• Real-time carrier prefix database analysis</li>
                <li>• Mobile Number Portability (MNP) tracking</li>
                <li>• Network operator assignment records</li>
                <li>• MVNO (Mobile Virtual Network Operator) identification</li>
                <li>• Historical carrier assignment patterns</li>
                <li>• Cross-reference with telecom authority databases</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Location Intelligence Sources</h4>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• Geographic numbering plan analysis</li>
                <li>• Area code to city mapping databases</li>
                <li>• Landline exchange location records</li>
                <li>• Mobile cell tower coverage areas</li>
                <li>• Postal code correlation systems</li>
                <li>• Administrative boundary databases</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Data Accuracy & Validation</h4>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• ITU-T E.164 international standard compliance</li>
                <li>• Regular updates from telecom authorities</li>
                <li>• Multi-source data verification</li>
                <li>• Pattern recognition algorithms</li>
                <li>• Historical data trend analysis</li>
                <li>• Real-time database synchronization</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Privacy & Compliance</h4>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• No personal information collection or storage</li>
                <li>• GDPR and privacy regulation compliant</li>
                <li>• Educational and research purposes only</li>
                <li>• No real-time location tracking capabilities</li>
                <li>• Respects telecommunications privacy laws</li>
                <li>• Transparent about data limitations and sources</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;