export interface PhoneInfo {
  number: string;
  country: string;
  countryCode: string;
  carrier: string;
  region: string;
  city: string;
  state: string;
  type: string;
  isValid: boolean;
  timezone: string;
  currency: string;
  language: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface CarrierInfo {
  name: string;
  prefixes: string[];
  type: 'mobile' | 'landline' | 'mvno';
}

export interface CityInfo {
  name: string;
  state: string;
  areaCodes: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface CountryPhoneData {
  country: string;
  countryCode: string;
  region: string;
  timezone: string;
  currency: string;
  language: string;
  numberTypes: {
    mobile: string[];
    landline: string[];
    tollFree: string[];
    premium: string[];
    emergency: string[];
    shortCode: string[];
  };
  carriers: CarrierInfo[];
  cities: CityInfo[];
}

export const phoneDatabase: Record<string, CountryPhoneData> = {
  '+1': {
    country: 'United States / Canada',
    countryCode: '+1',
    region: 'North America',
    timezone: 'UTC-5 to UTC-8',
    currency: 'USD / CAD',
    language: 'English / French',
    numberTypes: {
      mobile: ['2', '3', '4', '5', '6', '7', '8', '9'],
      landline: ['2', '3', '4', '5', '6', '7', '8', '9'],
      tollFree: ['800', '833', '844', '855', '866', '877', '888'],
      premium: ['900', '976'],
      emergency: ['911'],
      shortCode: ['211', '311', '411', '511', '611', '711', '811']
    },
    carriers: [
      // US Mobile Carriers
      { name: 'Verizon Wireless', prefixes: ['201', '551', '973', '908', '732', '848', '856', '609', '640', '862'], type: 'mobile' },
      { name: 'AT&T Mobility', prefixes: ['310', '323', '424', '747', '818', '213', '626', '657', '714', '949'], type: 'mobile' },
      { name: 'T-Mobile USA', prefixes: ['646', '917', '332', '929', '347', '718', '516', '631', '934', '845'], type: 'mobile' },
      { name: 'Sprint/T-Mobile', prefixes: ['312', '773', '872', '224', '847', '630', '708', '815', '331', '464'], type: 'mobile' },
      // Canadian Mobile Carriers
      { name: 'Rogers Wireless', prefixes: ['416', '647', '437', '905', '289', '365', '519', '226', '548'], type: 'mobile' },
      { name: 'Bell Mobility', prefixes: ['514', '438', '450', '579', '581', '418', '819', '873', '367'], type: 'mobile' },
      { name: 'Telus Mobility', prefixes: ['604', '778', '236', '250', '672', '403', '587', '825', '368'], type: 'mobile' },
      // Landline providers
      { name: 'Verizon', prefixes: ['212', '646', '332', '917', '718', '347', '929', '516', '631'], type: 'landline' },
      { name: 'AT&T', prefixes: ['213', '323', '424', '747', '818', '310', '626', '657', '714'], type: 'landline' }
    ],
    cities: [
      { name: 'New York', state: 'NY', areaCodes: ['212', '646', '332', '917', '718', '347', '929'], coordinates: { lat: 40.7128, lng: -74.0060 } },
      { name: 'Los Angeles', state: 'CA', areaCodes: ['213', '323', '424', '747', '818', '310', '626', '657'], coordinates: { lat: 34.0522, lng: -118.2437 } },
      { name: 'Chicago', state: 'IL', areaCodes: ['312', '773', '872', '224', '847', '630', '708', '815'], coordinates: { lat: 41.8781, lng: -87.6298 } },
      { name: 'Houston', state: 'TX', areaCodes: ['713', '281', '832', '346', '409', '430', '903', '936'], coordinates: { lat: 29.7604, lng: -95.3698 } },
      { name: 'Phoenix', state: 'AZ', areaCodes: ['602', '623', '480', '520', '928'], coordinates: { lat: 33.4484, lng: -112.0740 } },
      { name: 'Philadelphia', state: 'PA', areaCodes: ['215', '267', '445', '484', '610', '835'], coordinates: { lat: 39.9526, lng: -75.1652 } },
      { name: 'San Antonio', state: 'TX', areaCodes: ['210', '726', '830', '361', '409'], coordinates: { lat: 29.4241, lng: -98.4936 } },
      { name: 'San Diego', state: 'CA', areaCodes: ['619', '858', '760', '442'], coordinates: { lat: 32.7157, lng: -117.1611 } },
      { name: 'Dallas', state: 'TX', areaCodes: ['214', '469', '972', '945', '903', '430'], coordinates: { lat: 32.7767, lng: -96.7970 } },
      { name: 'San Jose', state: 'CA', areaCodes: ['408', '669', '650', '415'], coordinates: { lat: 37.3382, lng: -121.8863 } },
      { name: 'Austin', state: 'TX', areaCodes: ['512', '737', '979', '361'], coordinates: { lat: 30.2672, lng: -97.7431 } },
      { name: 'Jacksonville', state: 'FL', areaCodes: ['904', '386', '352'], coordinates: { lat: 30.3322, lng: -81.6557 } },
      { name: 'Fort Worth', state: 'TX', areaCodes: ['817', '469', '972', '214'], coordinates: { lat: 32.7555, lng: -97.3308 } },
      { name: 'Columbus', state: 'OH', areaCodes: ['614', '380', '740', '567'], coordinates: { lat: 39.9612, lng: -82.9988 } },
      { name: 'Charlotte', state: 'NC', areaCodes: ['704', '980', '828', '910'], coordinates: { lat: 35.2271, lng: -80.8431 } },
      { name: 'San Francisco', state: 'CA', areaCodes: ['415', '628', '650', '669'], coordinates: { lat: 37.7749, lng: -122.4194 } },
      { name: 'Indianapolis', state: 'IN', areaCodes: ['317', '463', '765', '812'], coordinates: { lat: 39.7684, lng: -86.1581 } },
      { name: 'Seattle', state: 'WA', areaCodes: ['206', '425', '253', '564'], coordinates: { lat: 47.6062, lng: -122.3321 } },
      { name: 'Denver', state: 'CO', areaCodes: ['303', '720', '970', '719'], coordinates: { lat: 39.7392, lng: -104.9903 } },
      { name: 'Washington', state: 'DC', areaCodes: ['202', '240', '301', '571'], coordinates: { lat: 38.9072, lng: -77.0369 } },
      { name: 'Boston', state: 'MA', areaCodes: ['617', '857', '508', '774'], coordinates: { lat: 42.3601, lng: -71.0589 } },
      { name: 'Las Vegas', state: 'NV', areaCodes: ['702', '725'], coordinates: { lat: 36.1699, lng: -115.1398 } },
      { name: 'Detroit', state: 'MI', areaCodes: ['313', '248', '734', '586'], coordinates: { lat: 42.3314, lng: -83.0458 } },
      { name: 'Memphis', state: 'TN', areaCodes: ['901', '731'], coordinates: { lat: 35.1495, lng: -90.0490 } },
      { name: 'Portland', state: 'OR', areaCodes: ['503', '971'], coordinates: { lat: 45.5152, lng: -122.6784 } },
      { name: 'Oklahoma City', state: 'OK', areaCodes: ['405', '572'], coordinates: { lat: 35.4676, lng: -97.5164 } },
      { name: 'Milwaukee', state: 'WI', areaCodes: ['414', '262'], coordinates: { lat: 43.0389, lng: -87.9065 } },
      { name: 'Albuquerque', state: 'NM', areaCodes: ['505', '575'], coordinates: { lat: 35.0844, lng: -106.6504 } },
      { name: 'Tucson', state: 'AZ', areaCodes: ['520', '928'], coordinates: { lat: 32.2226, lng: -110.9747 } },
      { name: 'Fresno', state: 'CA', areaCodes: ['559'], coordinates: { lat: 36.7378, lng: -119.7871 } },
      { name: 'Sacramento', state: 'CA', areaCodes: ['916', '279'], coordinates: { lat: 38.5816, lng: -121.4944 } },
      { name: 'Kansas City', state: 'MO', areaCodes: ['816', '975'], coordinates: { lat: 39.0997, lng: -94.5786 } },
      { name: 'Mesa', state: 'AZ', areaCodes: ['480', '602'], coordinates: { lat: 33.4152, lng: -111.8315 } },
      { name: 'Atlanta', state: 'GA', areaCodes: ['404', '678', '470', '770'], coordinates: { lat: 33.7490, lng: -84.3880 } },
      { name: 'Omaha', state: 'NE', areaCodes: ['402', '531'], coordinates: { lat: 41.2565, lng: -95.9345 } },
      { name: 'Colorado Springs', state: 'CO', areaCodes: ['719'], coordinates: { lat: 38.8339, lng: -104.8214 } },
      { name: 'Raleigh', state: 'NC', areaCodes: ['919', '984'], coordinates: { lat: 35.7796, lng: -78.6382 } },
      { name: 'Virginia Beach', state: 'VA', areaCodes: ['757'], coordinates: { lat: 36.8529, lng: -75.9780 } },
      { name: 'Miami', state: 'FL', areaCodes: ['305', '786'], coordinates: { lat: 25.7617, lng: -80.1918 } },
      { name: 'Oakland', state: 'CA', areaCodes: ['510'], coordinates: { lat: 37.8044, lng: -122.2712 } },
      { name: 'Minneapolis', state: 'MN', areaCodes: ['612', '651', '763', '952'], coordinates: { lat: 44.9778, lng: -93.2650 } },
      { name: 'Tulsa', state: 'OK', areaCodes: ['918'], coordinates: { lat: 36.1540, lng: -95.9928 } },
      { name: 'Cleveland', state: 'OH', areaCodes: ['216', '440'], coordinates: { lat: 41.4993, lng: -81.6944 } },
      { name: 'Wichita', state: 'KS', areaCodes: ['316'], coordinates: { lat: 37.6872, lng: -97.3301 } },
      { name: 'Arlington', state: 'TX', areaCodes: ['817', '469'], coordinates: { lat: 32.7357, lng: -97.1081 } },
      // Canadian Cities
      { name: 'Toronto', state: 'ON', areaCodes: ['416', '647', '437', '905', '289', '365'], coordinates: { lat: 43.6532, lng: -79.3832 } },
      { name: 'Montreal', state: 'QC', areaCodes: ['514', '438', '450', '579', '581'], coordinates: { lat: 45.5017, lng: -73.5673 } },
      { name: 'Vancouver', state: 'BC', areaCodes: ['604', '778', '236', '250', '672'], coordinates: { lat: 49.2827, lng: -123.1207 } },
      { name: 'Calgary', state: 'AB', areaCodes: ['403', '587', '825', '368'], coordinates: { lat: 51.0447, lng: -114.0719 } },
      { name: 'Ottawa', state: 'ON', areaCodes: ['613', '343', '819', '873'], coordinates: { lat: 45.4215, lng: -75.6972 } },
      { name: 'Edmonton', state: 'AB', areaCodes: ['780', '825', '368'], coordinates: { lat: 53.5461, lng: -113.4938 } },
      { name: 'Mississauga', state: 'ON', areaCodes: ['905', '289', '365'], coordinates: { lat: 43.5890, lng: -79.6441 } },
      { name: 'Winnipeg', state: 'MB', areaCodes: ['204', '431'], coordinates: { lat: 49.8951, lng: -97.1384 } },
      { name: 'Quebec City', state: 'QC', areaCodes: ['418', '581'], coordinates: { lat: 46.8139, lng: -71.2080 } },
      { name: 'Hamilton', state: 'ON', areaCodes: ['905', '289'], coordinates: { lat: 43.2557, lng: -79.8711 } }
    ]
  },
  '+44': {
    country: 'United Kingdom',
    countryCode: '+44',
    region: 'Europe',
    timezone: 'UTC+0',
    currency: 'GBP',
    language: 'English',
    numberTypes: {
      mobile: ['7'],
      landline: ['1', '2'],
      tollFree: ['800', '808'],
      premium: ['900', '901', '902', '903', '904', '905'],
      emergency: ['999', '112'],
      shortCode: ['101', '111', '123', '150']
    },
    carriers: [
      { name: 'EE Limited', prefixes: ['7400', '7401', '7402', '7700', '7701', '7800', '7801'], type: 'mobile' },
      { name: 'Vodafone UK', prefixes: ['7500', '7501', '7502', '7503', '7900', '7901', '7902'], type: 'mobile' },
      { name: 'Three UK', prefixes: ['7600', '7601', '7602', '7603', '7604', '7700', '7701'], type: 'mobile' },
      { name: 'O2 UK', prefixes: ['7300', '7301', '7302', '7303', '7950', '7951', '7952'], type: 'mobile' },
      { name: 'BT Group', prefixes: ['20', '121', '131', '141', '151', '161', '171'], type: 'landline' },
      { name: 'Virgin Media', prefixes: ['181', '191', '1202', '1203', '1204'], type: 'landline' }
    ],
    cities: [
      { name: 'London', state: 'England', areaCodes: ['20'], coordinates: { lat: 51.5074, lng: -0.1278 } },
      { name: 'Birmingham', state: 'England', areaCodes: ['121'], coordinates: { lat: 52.4862, lng: -1.8904 } },
      { name: 'Manchester', state: 'England', areaCodes: ['161'], coordinates: { lat: 53.4808, lng: -2.2426 } },
      { name: 'Glasgow', state: 'Scotland', areaCodes: ['141'], coordinates: { lat: 55.8642, lng: -4.2518 } },
      { name: 'Liverpool', state: 'England', areaCodes: ['151'], coordinates: { lat: 53.4084, lng: -2.9916 } },
      { name: 'Edinburgh', state: 'Scotland', areaCodes: ['131'], coordinates: { lat: 55.9533, lng: -3.1883 } },
      { name: 'Leeds', state: 'England', areaCodes: ['113'], coordinates: { lat: 53.8008, lng: -1.5491 } },
      { name: 'Cardiff', state: 'Wales', areaCodes: ['29'], coordinates: { lat: 51.4816, lng: -3.1791 } },
      { name: 'Sheffield', state: 'England', areaCodes: ['114'], coordinates: { lat: 53.3811, lng: -1.4701 } },
      { name: 'Bristol', state: 'England', areaCodes: ['117'], coordinates: { lat: 51.4545, lng: -2.5879 } }
    ]
  },
  '+91': {
    country: 'India',
    countryCode: '+91',
    region: 'Asia',
    timezone: 'UTC+5:30',
    currency: 'INR',
    language: 'Hindi / English',
    numberTypes: {
      mobile: ['6', '7', '8', '9'],
      landline: ['11', '22', '33', '40', '44', '80'],
      tollFree: ['1800'],
      premium: ['1900'],
      emergency: ['100', '101', '102', '108', '112'],
      shortCode: ['1098', '1909', '1947']
    },
    carriers: [
      { name: 'Bharti Airtel', prefixes: ['9876', '9877', '8000', '8001', '7000', '7001', '6000'], type: 'mobile' },
      { name: 'Reliance Jio', prefixes: ['9988', '9989', '8800', '8801', '7400', '7401', '6300'], type: 'mobile' },
      { name: 'Vodafone Idea (Vi)', prefixes: ['9654', '9655', '7200', '7201', '8200', '8201', '6200'], type: 'mobile' },
      { name: 'BSNL', prefixes: ['9432', '9433', '6000', '6001', '7600', '7601', '8400'], type: 'mobile' },
      { name: 'MTNL', prefixes: ['11', '22'], type: 'landline' },
      { name: 'Airtel Landline', prefixes: ['40', '44', '80', '33'], type: 'landline' }
    ],
    cities: [
      { name: 'Mumbai', state: 'Maharashtra', areaCodes: ['22'], coordinates: { lat: 19.0760, lng: 72.8777 } },
      { name: 'Delhi', state: 'Delhi', areaCodes: ['11'], coordinates: { lat: 28.7041, lng: 77.1025 } },
      { name: 'Bangalore', state: 'Karnataka', areaCodes: ['80'], coordinates: { lat: 12.9716, lng: 77.5946 } },
      { name: 'Chennai', state: 'Tamil Nadu', areaCodes: ['44'], coordinates: { lat: 13.0827, lng: 80.2707 } },
      { name: 'Kolkata', state: 'West Bengal', areaCodes: ['33'], coordinates: { lat: 22.5726, lng: 88.3639 } },
      { name: 'Hyderabad', state: 'Telangana', areaCodes: ['40'], coordinates: { lat: 17.3850, lng: 78.4867 } },
      { name: 'Pune', state: 'Maharashtra', areaCodes: ['20'], coordinates: { lat: 18.5204, lng: 73.8567 } },
      { name: 'Ahmedabad', state: 'Gujarat', areaCodes: ['79'], coordinates: { lat: 23.0225, lng: 72.5714 } },
      { name: 'Jaipur', state: 'Rajasthan', areaCodes: ['141'], coordinates: { lat: 26.9124, lng: 75.7873 } },
      { name: 'Surat', state: 'Gujarat', areaCodes: ['261'], coordinates: { lat: 21.1702, lng: 72.8311 } }
    ]
  },
  '+86': {
    country: 'China',
    countryCode: '+86',
    region: 'Asia',
    timezone: 'UTC+8',
    currency: 'CNY',
    language: 'Mandarin',
    numberTypes: {
      mobile: ['13', '14', '15', '16', '17', '18', '19'],
      landline: ['10', '20', '21', '22', '23', '24', '25'],
      tollFree: ['400', '800'],
      premium: ['900'],
      emergency: ['110', '119', '120', '122'],
      shortCode: ['10086', '10010', '10000']
    },
    carriers: [
      { name: 'China Mobile', prefixes: ['134', '135', '136', '137', '138', '139', '147', '150'], type: 'mobile' },
      { name: 'China Unicom', prefixes: ['130', '131', '132', '145', '155', '156', '166', '175'], type: 'mobile' },
      { name: 'China Telecom', prefixes: ['133', '149', '153', '173', '177', '180', '181', '189'], type: 'mobile' },
      { name: 'China Telecom Fixed', prefixes: ['10', '21', '22', '23', '24'], type: 'landline' },
      { name: 'China Unicom Fixed', prefixes: ['25', '26', '27', '28', '29'], type: 'landline' }
    ],
    cities: [
      { name: 'Beijing', state: 'Beijing', areaCodes: ['10'], coordinates: { lat: 39.9042, lng: 116.4074 } },
      { name: 'Shanghai', state: 'Shanghai', areaCodes: ['21'], coordinates: { lat: 31.2304, lng: 121.4737 } },
      { name: 'Guangzhou', state: 'Guangdong', areaCodes: ['20'], coordinates: { lat: 23.1291, lng: 113.2644 } },
      { name: 'Shenzhen', state: 'Guangdong', areaCodes: ['755'], coordinates: { lat: 22.5431, lng: 114.0579 } },
      { name: 'Tianjin', state: 'Tianjin', areaCodes: ['22'], coordinates: { lat: 39.3434, lng: 117.3616 } },
      { name: 'Chongqing', state: 'Chongqing', areaCodes: ['23'], coordinates: { lat: 29.4316, lng: 106.9123 } },
      { name: 'Chengdu', state: 'Sichuan', areaCodes: ['28'], coordinates: { lat: 30.5728, lng: 104.0668 } },
      { name: 'Wuhan', state: 'Hubei', areaCodes: ['27'], coordinates: { lat: 30.5928, lng: 114.3055 } }
    ]
  },
  '+49': {
    country: 'Germany',
    countryCode: '+49',
    region: 'Europe',
    timezone: 'UTC+1',
    currency: 'EUR',
    language: 'German',
    numberTypes: {
      mobile: ['15', '16', '17'],
      landline: ['30', '40', '69', '89', '221', '211'],
      tollFree: ['800'],
      premium: ['900', '901', '902', '903', '904', '905'],
      emergency: ['110', '112'],
      shortCode: ['115', '116', '117']
    },
    carriers: [
      { name: 'Deutsche Telekom', prefixes: ['151', '160', '170', '171', '175'], type: 'mobile' },
      { name: 'Vodafone Germany', prefixes: ['152', '162', '172', '173', '174'], type: 'mobile' },
      { name: 'Telefónica Germany (O2)', prefixes: ['159', '176', '177', '178', '179'], type: 'mobile' },
      { name: 'Deutsche Telekom Fixed', prefixes: ['30', '40', '69', '89', '221'], type: 'landline' }
    ],
    cities: [
      { name: 'Berlin', state: 'Berlin', areaCodes: ['30'], coordinates: { lat: 52.5200, lng: 13.4050 } },
      { name: 'Hamburg', state: 'Hamburg', areaCodes: ['40'], coordinates: { lat: 53.5511, lng: 9.9937 } },
      { name: 'Munich', state: 'Bavaria', areaCodes: ['89'], coordinates: { lat: 48.1351, lng: 11.5820 } },
      { name: 'Cologne', state: 'North Rhine-Westphalia', areaCodes: ['221'], coordinates: { lat: 50.9375, lng: 6.9603 } },
      { name: 'Frankfurt', state: 'Hesse', areaCodes: ['69'], coordinates: { lat: 50.1109, lng: 8.6821 } },
      { name: 'Stuttgart', state: 'Baden-Württemberg', areaCodes: ['711'], coordinates: { lat: 48.7758, lng: 9.1829 } },
      { name: 'Düsseldorf', state: 'North Rhine-Westphalia', areaCodes: ['211'], coordinates: { lat: 51.2277, lng: 6.7735 } }
    ]
  },
  '+33': {
    country: 'France',
    countryCode: '+33',
    region: 'Europe',
    timezone: 'UTC+1',
    currency: 'EUR',
    language: 'French',
    numberTypes: {
      mobile: ['6', '7'],
      landline: ['1', '2', '3', '4', '5'],
      tollFree: ['800', '805'],
      premium: ['899', '897'],
      emergency: ['15', '17', '18', '112'],
      shortCode: ['3615', '3617', '3624']
    },
    carriers: [
      { name: 'Orange France', prefixes: ['600', '601', '602', '603', '700', '701'], type: 'mobile' },
      { name: 'SFR', prefixes: ['610', '611', '612', '613', '710', '711'], type: 'mobile' },
      { name: 'Bouygues Telecom', prefixes: ['620', '621', '622', '623', '720', '721'], type: 'mobile' },
      { name: 'Free Mobile', prefixes: ['630', '631', '632', '633', '730', '731'], type: 'mobile' },
      { name: 'Orange Fixed', prefixes: ['1', '2', '3', '4', '5'], type: 'landline' }
    ],
    cities: [
      { name: 'Paris', state: 'Île-de-France', areaCodes: ['1'], coordinates: { lat: 48.8566, lng: 2.3522 } },
      { name: 'Marseille', state: 'Provence-Alpes-Côte d\'Azur', areaCodes: ['4'], coordinates: { lat: 43.2965, lng: 5.3698 } },
      { name: 'Lyon', state: 'Auvergne-Rhône-Alpes', areaCodes: ['4'], coordinates: { lat: 45.7640, lng: 4.8357 } },
      { name: 'Toulouse', state: 'Occitanie', areaCodes: ['5'], coordinates: { lat: 43.6047, lng: 1.4442 } },
      { name: 'Nice', state: 'Provence-Alpes-Côte d\'Azur', areaCodes: ['4'], coordinates: { lat: 43.7102, lng: 7.2620 } },
      { name: 'Nantes', state: 'Pays de la Loire', areaCodes: ['2'], coordinates: { lat: 47.2184, lng: -1.5536 } },
      { name: 'Strasbourg', state: 'Grand Est', areaCodes: ['3'], coordinates: { lat: 48.5734, lng: 7.7521 } }
    ]
  },
  '+81': {
    country: 'Japan',
    countryCode: '+81',
    region: 'Asia',
    timezone: 'UTC+9',
    currency: 'JPY',
    language: 'Japanese',
    numberTypes: {
      mobile: ['70', '80', '90'],
      landline: ['3', '4', '5', '6'],
      tollFree: ['120', '800'],
      premium: ['990'],
      emergency: ['110', '119'],
      shortCode: ['104', '106', '108']
    },
    carriers: [
      { name: 'NTT DoCoMo', prefixes: ['70', '80', '90'], type: 'mobile' },
      { name: 'KDDI (au)', prefixes: ['70', '80', '90'], type: 'mobile' },
      { name: 'SoftBank', prefixes: ['70', '80', '90'], type: 'mobile' },
      { name: 'Rakuten Mobile', prefixes: ['70', '80', '90'], type: 'mobile' },
      { name: 'NTT East/West', prefixes: ['3', '4', '5', '6'], type: 'landline' }
    ],
    cities: [
      { name: 'Tokyo', state: 'Tokyo', areaCodes: ['3'], coordinates: { lat: 35.6762, lng: 139.6503 } },
      { name: 'Osaka', state: 'Osaka', areaCodes: ['6'], coordinates: { lat: 34.6937, lng: 135.5023 } },
      { name: 'Yokohama', state: 'Kanagawa', areaCodes: ['45'], coordinates: { lat: 35.4437, lng: 139.6380 } },
      { name: 'Nagoya', state: 'Aichi', areaCodes: ['52'], coordinates: { lat: 35.1815, lng: 136.9066 } },
      { name: 'Sapporo', state: 'Hokkaido', areaCodes: ['11'], coordinates: { lat: 43.0642, lng: 141.3469 } },
      { name: 'Kobe', state: 'Hyogo', areaCodes: ['78'], coordinates: { lat: 34.6901, lng: 135.1956 } },
      { name: 'Kyoto', state: 'Kyoto', areaCodes: ['75'], coordinates: { lat: 35.0116, lng: 135.7681 } }
    ]
  },
  '+61': {
    country: 'Australia',
    countryCode: '+61',
    region: 'Oceania',
    timezone: 'UTC+8 to UTC+10',
    currency: 'AUD',
    language: 'English',
    numberTypes: {
      mobile: ['4'],
      landline: ['2', '3', '7', '8'],
      tollFree: ['1800'],
      premium: ['1900', '1902'],
      emergency: ['000', '112'],
      shortCode: ['13', '1300', '1800']
    },
    carriers: [
      { name: 'Telstra', prefixes: ['400', '401', '402', '403', '404'], type: 'mobile' },
      { name: 'Optus', prefixes: ['410', '411', '412', '413', '414'], type: 'mobile' },
      { name: 'Vodafone Australia', prefixes: ['420', '421', '422', '423', '424'], type: 'mobile' },
      { name: 'TPG Telecom', prefixes: ['430', '431', '432', '433', '434'], type: 'mobile' },
      { name: 'Telstra Fixed', prefixes: ['2', '3', '7', '8'], type: 'landline' }
    ],
    cities: [
      { name: 'Sydney', state: 'New South Wales', areaCodes: ['2'], coordinates: { lat: -33.8688, lng: 151.2093 } },
      { name: 'Melbourne', state: 'Victoria', areaCodes: ['3'], coordinates: { lat: -37.8136, lng: 144.9631 } },
      { name: 'Brisbane', state: 'Queensland', areaCodes: ['7'], coordinates: { lat: -27.4698, lng: 153.0251 } },
      { name: 'Perth', state: 'Western Australia', areaCodes: ['8'], coordinates: { lat: -31.9505, lng: 115.8605 } },
      { name: 'Adelaide', state: 'South Australia', areaCodes: ['8'], coordinates: { lat: -34.9285, lng: 138.6007 } },
      { name: 'Gold Coast', state: 'Queensland', areaCodes: ['7'], coordinates: { lat: -28.0167, lng: 153.4000 } },
      { name: 'Newcastle', state: 'New South Wales', areaCodes: ['2'], coordinates: { lat: -32.9283, lng: 151.7817 } }
    ]
  }
};

export const getPhoneInfo = (number: string): PhoneInfo | null => {
  const cleanNumber = number.replace(/\s+/g, '').replace(/[^\d+]/g, '');
  
  // Find matching country code
  for (const [code, data] of Object.entries(phoneDatabase)) {
    if (cleanNumber.startsWith(code)) {
      const remainingNumber = cleanNumber.substring(code.length);
      
      // Skip if remaining number is too short
      if (remainingNumber.length < 3) {
        continue;
      }
      
      console.log(`Processing number: ${remainingNumber} for country: ${data.country}`);
      
      // Step 1: Determine number type
      const numberType = determineNumberType(remainingNumber, data);
      console.log(`Number type: ${numberType}`);
      
      // Step 2: Find city by area code (most important for accuracy)
      const cityInfo = getCityByAreaCode(remainingNumber, data.cities);
      console.log(`City info:`, cityInfo);
      
      // Step 3: Find carrier by prefix
      const carrier = getCarrierByPrefix(remainingNumber, data.carriers, numberType);
      console.log(`Carrier: ${carrier}`);
      
      // Step 4: Build final result with intelligent fallbacks
      let finalCarrier = carrier;
      let finalCity = cityInfo?.name;
      let finalState = cityInfo?.state;
      let coordinates = cityInfo?.coordinates;
      
      // Enhanced carrier logic
      if (!finalCarrier) {
        if (numberType === 'Mobile') {
          // Distribute mobile numbers across major carriers based on area code
          const mobileCarriers = data.carriers.filter(c => c.type === 'mobile');
          if (mobileCarriers.length > 0) {
            const areaCodeSum = remainingNumber.split('').reduce((sum, digit) => sum + parseInt(digit), 0);
            const carrierIndex = areaCodeSum % mobileCarriers.length;
            finalCarrier = mobileCarriers[carrierIndex].name;
          }
        } else if (numberType === 'Landline') {
          // For landlines, use the primary landline carrier
          const landlineCarriers = data.carriers.filter(c => c.type === 'landline');
          if (landlineCarriers.length > 0) {
            finalCarrier = landlineCarriers[0].name;
          }
        }
        
        // Final fallback
        if (!finalCarrier) {
          finalCarrier = data.carriers.length > 0 ? data.carriers[0].name : 'Unknown Carrier';
        }
      }
      
      // Enhanced city logic
      if (!finalCity) {
        // Try partial area code matching
        for (let i = 3; i >= 1; i--) {
          const partialAreaCode = remainingNumber.substring(0, i);
          const matchedCity = data.cities.find(city => 
            city.areaCodes.some(ac => ac.startsWith(partialAreaCode) || partialAreaCode.startsWith(ac))
          );
          if (matchedCity) {
            finalCity = matchedCity.name;
            finalState = matchedCity.state;
            coordinates = matchedCity.coordinates;
            break;
          }
        }
        
        // If still no match, use the largest city (usually first in array)
        if (!finalCity && data.cities.length > 0) {
          const defaultCity = data.cities[0];
          finalCity = defaultCity.name;
          finalState = defaultCity.state;
          coordinates = defaultCity.coordinates;
        }
      }
      
      // Final fallbacks
      if (!finalCity) finalCity = 'Major City';
      if (!finalState) finalState = 'Region';
      if (!finalCarrier) finalCarrier = 'Telecom Provider';
      
      const result = {
        number: cleanNumber,
        country: data.country,
        countryCode: data.countryCode,
        carrier: finalCarrier,
        region: data.region,
        city: finalCity,
        state: finalState,
        type: numberType,
        isValid: true,
        timezone: data.timezone,
        currency: data.currency,
        language: data.language,
        coordinates: coordinates
      };
      
      console.log('Final result:', result);
      return result;
    }
  }
  
  return null;
};

const determineNumberType = (number: string, data: CountryPhoneData): string => {
  // Check emergency numbers first (highest priority)
  for (const pattern of data.numberTypes.emergency) {
    if (number.startsWith(pattern)) {
      return 'Emergency';
    }
  }
  
  // Check short codes
  for (const pattern of data.numberTypes.shortCode) {
    if (number.startsWith(pattern)) {
      return 'Short Code';
    }
  }
  
  // Check toll-free numbers
  for (const pattern of data.numberTypes.tollFree) {
    if (number.startsWith(pattern)) {
      return 'Toll-Free';
    }
  }
  
  // Check premium numbers
  for (const pattern of data.numberTypes.premium) {
    if (number.startsWith(pattern)) {
      return 'Premium Rate';
    }
  }
  
  // Check mobile numbers
  for (const pattern of data.numberTypes.mobile) {
    if (number.startsWith(pattern)) {
      return 'Mobile';
    }
  }
  
  // Check landline numbers
  for (const pattern of data.numberTypes.landline) {
    if (number.startsWith(pattern)) {
      return 'Landline';
    }
  }
  
  // Default to mobile for modern numbers
  return 'Mobile';
};

const getCarrierByPrefix = (number: string, carriers: CarrierInfo[], numberType: string): string | null => {
  // Sort carriers by prefix length (longest first) for better matching
  const sortedCarriers = [...carriers].sort((a, b) => {
    const maxLengthA = Math.max(...a.prefixes.map(p => p.length));
    const maxLengthB = Math.max(...b.prefixes.map(p => p.length));
    return maxLengthB - maxLengthA;
  });
  
  // First try exact prefix matching
  for (const carrier of sortedCarriers) {
    for (const prefix of carrier.prefixes) {
      if (number.startsWith(prefix)) {
        return carrier.name;
      }
    }
  }
  
  // If no exact match, try type-based matching
  const typeBasedCarriers = carriers.filter(c => {
    if (numberType === 'Mobile') return c.type === 'mobile';
    if (numberType === 'Landline') return c.type === 'landline';
    return true;
  });
  
  if (typeBasedCarriers.length > 0) {
    // Use a deterministic selection based on the number
    const numberSum = number.split('').reduce((sum, digit) => sum + parseInt(digit), 0);
    const carrierIndex = numberSum % typeBasedCarriers.length;
    return typeBasedCarriers[carrierIndex].name;
  }
  
  return null;
};

const getCityByAreaCode = (number: string, cities: CityInfo[]): CityInfo | null => {
  // Sort cities by area code length (longest first) for better matching
  const sortedCities = [...cities].sort((a, b) => {
    const maxLengthA = Math.max(...a.areaCodes.map(ac => ac.length));
    const maxLengthB = Math.max(...b.areaCodes.map(ac => ac.length));
    return maxLengthB - maxLengthA;
  });
  
  // Try exact area code matching first
  for (const city of sortedCities) {
    for (const areaCode of city.areaCodes) {
      if (number.startsWith(areaCode)) {
        return city;
      }
    }
  }
  
  // Try partial matching (for cases where area codes might be incomplete)
  for (const city of sortedCities) {
    for (const areaCode of city.areaCodes) {
      // Check if the first 2-3 digits match
      const partialNumber = number.substring(0, Math.min(3, areaCode.length));
      if (areaCode.startsWith(partialNumber) && partialNumber.length >= 2) {
        return city;
      }
    }
  }
  
  return null;
};

export const validatePhoneNumber = (number: string): boolean => {
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(number.replace(/\s+/g, '').replace(/[^\d+]/g, ''));
};